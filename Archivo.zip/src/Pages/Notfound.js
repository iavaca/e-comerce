import React, {Component} from "react";


class notfound extends Component{
    render(){
        return(
            <>
            <div>
               404
                </div></>
        )
    }
}
export default notfound;
