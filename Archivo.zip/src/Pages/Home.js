import React, {Component} from "react";
import Productos from "../Components/Productos";

class Home extends Component{
    render(){
        return(
            <>
            <div>
                <Productos />
                </div></>
        )
    }
}
export default Home;
